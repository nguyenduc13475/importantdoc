/*
* Author: Võ Tiến
* Date: 20.02.2023
* FB: https://www.facebook.com/profile.php?id=100056605580171
* FB nhóm: https://www.facebook.com/groups/211867931379013
* khóa học KTLT1: https://www.facebook.com/photo/?fbid=845258184037693&set=gm.404500422115762&idorvanity=211867931379013
*/


#ifndef _MAIN_1_H_
#define _MAIN_1_H_

#include <iostream>
#include <iomanip>
#include <cmath>
#include <cstring>
#include <climits>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;
//The library here is concretely set, students are not allowed to include any other libraries.


#define folder_input  "TestCase/input/input"
#define folder_output "TestCase/output/output"
#define folder_expect "TestCase/expect/expect"



#endif //_MAIN_1_H_