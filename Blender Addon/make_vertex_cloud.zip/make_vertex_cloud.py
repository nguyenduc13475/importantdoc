import bpy
import bmesh
from mathutils import Vector
from random import random

bl_info = {
    "name": "Make Vertex Cloud",
    "author": "Nguyen Van Duc",
    "version": (1, 0),
    "blender": (3, 5, 0),
    "location": "View 3D > Viewport Panel > Tab Cloud",
    "description": "Make Vertex Cloud",
    "category": "Cloud",
}


class MakeVertexCloudOperation(bpy.types.Operator):
    bl_idname = "vertex.makecloud"
    bl_label = "Make Vertex Cloud"

    cloud_radius: bpy.props.FloatProperty(default = 1)
    number_of_vertices: bpy.props.IntProperty(default = 20)

    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')
        obj = context.active_object
        me = obj.data
        bme = bmesh.new()
        bme.from_mesh(me)
        vertices = bme.verts

        is_in_group = []

        for v in vertices:
            if v.select:
                center_cloud = v.co
                vertices.remove(v)

                for i in range(self.number_of_vertices):
                    random_gen = lambda : random() * self.cloud_radius * 2 - self.cloud_radius
                    random_vec = Vector([coord + random_gen() for coord in center_cloud])
                    new_vertex = vertices.new(random_vec)
                    is_in_group.append(new_vertex)
                    
                break
        
        vertices.index_update()
        new_vertex_indices = [v.index for v in is_in_group]

        bme.to_mesh(me)
        bme.free()

        cloud_index = 0
        for vertex_group in obj.vertex_groups:
            if vertex_group.name.startswith("Vertex Cloud "):
                cloud_index = max(int(vertex_group.name[13:]), cloud_index)
        cloud_name = "Vertex Cloud " + str(cloud_index + 1)
        cloud_group = obj.vertex_groups.new(name = cloud_name)
        cloud_group.add(new_vertex_indices, 1, "REPLACE")

        bpy.ops.object.mode_set(mode = 'EDIT')

        return {'FINISHED'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
class MakeVertexCloudPanel(bpy.types.Panel):
    bl_label = "Make Vertex Cloud"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Cloud"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator(MakeVertexCloudOperation.bl_idname)

classes = [
    MakeVertexCloudOperation,
    MakeVertexCloudPanel
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()