import bpy
import bmesh
from mathutils import Vector
from random import random

bl_info = {
    "name": "Make Vertex Cloud",
    "author": "Nguyen Van Duc",
    "version": (1, 0),
    "blender": (3, 5, 0),
    "location": "View 3D > Viewport Panel > Tab Cloud",
    "description": "Make Vertex Cloud",
    "category": "Cloud",
}


class MakeVertexCloudOperation(bpy.types.Operator):
    bl_idname = "vertex.makecloud"
    bl_label = "Make Vertex Cloud"

    cloud_radius: bpy.props.FloatProperty(default = 1)
    number_of_vertices: bpy.props.IntProperty(default = 20)

    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')
        me = context.active_object.data
        bme = bmesh.new()
        bme.from_mesh(me)
        vertices = bme.verts

        for v in vertices:
            if v.select:
                center_cloud = v.co
                vertices.remove(v)

                for i in range(self.number_of_vertices):
                    random_gen = lambda : random() * self.cloud_radius * 2 - self.cloud_radius
                    random_vec = Vector([coord + random_gen() for coord in center_cloud])
                    vertices.new(random_vec)
                    
                break
        
        bme.to_mesh(me)
        bme.free()
        bpy.ops.object.mode_set(mode = 'EDIT')

        return {'FINISHED'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
class MakeVertexCloudPanel(bpy.types.Panel):
    bl_label = "Make Vertex Cloud"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Cloud"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator(MakeVertexCloudOperation.bl_idname)

classes = [
    MakeVertexCloudOperation,
    MakeVertexCloudPanel
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)