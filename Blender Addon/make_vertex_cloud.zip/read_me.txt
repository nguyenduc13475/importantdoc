Step 1, select 1 vertex in Edit Mode
Step 2, go to Viewport Panel, at "Cloud" Tab, Click "Make Vertex Cloud" button
Step 3, specify the radius of vertices cloud and number of verices
Step 3, see result, selected vertex become a random cloud of vertices