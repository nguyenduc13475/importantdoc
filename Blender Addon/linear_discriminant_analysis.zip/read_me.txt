Step 1, create an object with only vertices, and make different vertex group with prefix "Vertex Cloud " + a number to identify each class
Step 2, make sure the matrix_basis property of object is identity and it has no parent
Step 3, select the object and go to Viewport Panel, at "LDA" Tab, Click "Linear Discriminant Analysis" to transform the Vertex Cloud