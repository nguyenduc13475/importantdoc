import bpy
import numpy as np
from mathutils import Vector

bl_info = {
    "name": "Linear Discriminant Analysis",
    "author": "Nguyen Van Duc",
    "version": (1, 0),
    "blender": (3, 5, 0),
    "location": "View 3D > Viewport Panel > Tab LDA",
    "description": "Linear Discriminant Analysis",
    "category": "Dimension Reduce",
}


class LDAOperation(bpy.types.Operator):
    bl_idname = "data.lda"
    bl_label = "Linear Discriminant Analysis"

    dimension_reduced_to: bpy.props.IntProperty(default = 1)

    def execute(self, context):
        obj = context.active_object
        me = obj.data
        vertex_groups = obj.vertex_groups

        existed_classes = {}

        for vertex in me.vertices:
            for vertex_container in vertex.groups:
                vertex_group_name = vertex_groups[vertex_container.group].name
                if vertex_group_name.startswith("Vertex Cloud ") and vertex_container.weight == 1:
                    existed_classes.setdefault(vertex_group_name, [])
                    existed_classes[vertex_group_name].append(vertex.co.to_tuple())
                    break
        
        S_W = np.zeros((3, 3))
        D_mean = np.zeros((3, 1))
        D_i_mean_arr = []
        N_i_arr = []
        for cls in existed_classes.values():
            D_i = np.array(cls).T
            D_i_mean = D_i.mean(axis = 1, keepdims = True)
            D_i_centered = D_i - D_i_mean
            C_i = D_i_centered @ D_i_centered.T
            S_W += C_i
            N_i = D_i.shape[1]
            D_mean += D_i_mean * N_i
            D_i_mean_arr.append(D_i_mean)
            N_i_arr.append(N_i)

        D_mean /= len(me.vertices)
        S_W += 1e-7 * np.identity(3)

        S_B = np.zeros((3, 3))
        for D_i_mean, N_i in zip(D_i_mean_arr, N_i_arr):
            D_i_mean_centered = D_i_mean - D_mean
            R_i = N_i * D_i_mean_centered @ D_i_mean_centered.T
            S_B += R_i

        M = np.linalg.inv(S_W) @ S_B
        eigen_values, eigen_vectors = np.linalg.eig(M)
        sorted_indices = eigen_values.argsort()[::-1]
        eigen_values = eigen_values[sorted_indices]
        eigen_vectors = eigen_vectors[sorted_indices]

        if eigen_values[0] == eigen_values[1]: number_of_eigen = min(2, self.dimension_reduced_to)
        else: number_of_eigen = 1

        W = eigen_vectors[:,:number_of_eigen].T

        for vertex in me.vertices:
            new_coord = W @ np.array(vertex.co).reshape(3, 1)
            new_coord.resize(3)
            vertex.co = Vector(new_coord)

        return {'FINISHED'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
class LDAPanel(bpy.types.Panel):
    bl_label = "Linear Discriminant Analysis"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "LDA"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator(LDAOperation.bl_idname)

classes = [
    LDAOperation,
    LDAPanel
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()